/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentacion;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * 
 * @author Andre
 */
public class JFrameConfigurarPropuesta extends JFrame {

    // Componentes de navegación y estructura
    private JPanel pnlNavegacionLateral;
    private JPanel pnlContenedorCartas;
    private CardLayout cardLayout;

    // Botones de la barra lateral
    private JButton btnFolio;
    private JButton btnServicios;
    private JButton btnEquipo;
    private JButton btnProveedor;
    private JButton btnPersonal;
    private JButton btnResumen;

    // Instancias de los subpaneles (clases internas)
    private PNL_Folio pnlFolio;
    private PNL_Servicios pnlServicios;
    private PNL_Equipo pnlEquipo;
    private PNL_Proveedor pnlProveedor;
    private PNL_Personal pnlPersonal;
    private PNL_Resumen pnlResumen;

    public JFrameConfigurarPropuesta() {
        iniciarComponentes();
    }

    private void iniciarComponentes() {
        // Configuración de la pantalla principal
        setTitle("Configuración de Evento");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // --- BARRA LATERAL IZQUIERDA ---
        pnlNavegacionLateral = new JPanel(new GridLayout(8, 1, 5, 10));
        pnlNavegacionLateral.setBackground(new Color(25, 25, 25));
        pnlNavegacionLateral.setPreferredSize(new Dimension(180, 650));

        btnFolio = crearBotonNavegacion("Folio");
        btnServicios = crearBotonNavegacion("Servicios");
        btnEquipo = crearBotonNavegacion("Equipo");
        btnProveedor = crearBotonNavegacion("Proveedor");
        btnPersonal = crearBotonNavegacion("Personal");
        btnResumen = crearBotonNavegacion("Resumen");

        pnlNavegacionLateral.add(btnFolio);
        pnlNavegacionLateral.add(btnServicios);
        pnlNavegacionLateral.add(btnEquipo);
        pnlNavegacionLateral.add(btnProveedor);
        pnlNavegacionLateral.add(btnPersonal);
        pnlNavegacionLateral.add(btnResumen);

        // --- CONTENEDOR DINÁMICO (CARDLAYOUT) ---
        cardLayout = new CardLayout();
        pnlContenedorCartas = new JPanel(cardLayout);

        // Instanciación de los subpaneles
        pnlFolio = new PNL_Folio();
        pnlServicios = new PNL_Servicios();
        pnlEquipo = new PNL_Equipo();
        pnlProveedor = new PNL_Proveedor();
        pnlPersonal = new PNL_Personal();
        pnlResumen = new PNL_Resumen();

        // Agregar paneles al contenedor con sus identificadores
        pnlContenedorCartas.add(pnlFolio, "PNL_FOLIO");
        pnlContenedorCartas.add(pnlServicios, "PNL_SERVICIOS");
        pnlContenedorCartas.add(pnlEquipo, "PNL_EQUIPO");
        pnlContenedorCartas.add(pnlProveedor, "PNL_PROVEEDOR");
        pnlContenedorCartas.add(pnlPersonal, "PNL_PERSONAL");
        pnlContenedorCartas.add(pnlResumen, "PNL_RESUMEN");

        // Ensamblado general en la ventana principal
        add(pnlNavegacionLateral, BorderLayout.WEST);
        add(pnlContenedorCartas, BorderLayout.CENTER);

        // Eventos de los botones laterales para cambio de panel
        btnFolio.addActionListener(e -> navegarA("PNL_FOLIO"));
        btnServicios.addActionListener(e -> navegarA("PNL_SERVICIOS"));
        btnEquipo.addActionListener(e -> navegarA("PNL_EQUIPO"));
        btnProveedor.addActionListener(e -> navegarA("PNL_PROVEEDOR"));
        btnPersonal.addActionListener(e -> navegarA("PNL_PERSONAL"));
        btnResumen.addActionListener(e -> navegarA("PNL_RESUMEN"));

        // Abrir panel predilecto
        navegarA("PNL_FOLIO");
    }

    private JButton crearBotonNavegacion(String texto) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(45, 45, 45));
        btn.setFocusPainted(false);
        return btn;
    }

    public void navegarA(String nombrePanel) {
        cardLayout.show(pnlContenedorCartas, nombrePanel);
    }

    // =========================================================================
    //                            SUBPANELES INTERNOS
    // =========================================================================

    /**
     * Panel 1: Folio (Vista Inicial)
     */
    private class PNL_Folio extends JPanel {
        private JLabel lblTitulo;
        private JTextArea txtDetalles;
        private JButton btnContinuar;

        public PNL_Folio() {
            setLayout(new BorderLayout(15, 15));
            setBackground(new Color(220, 220, 220));

            lblTitulo = new JLabel("Folio", JLabel.LEFT);
            lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));

            txtDetalles = new JTextArea();
            txtDetalles.setEditable(false);

            btnContinuar = new JButton("Continuar");
            btnContinuar.setFont(new Font("Arial", Font.BOLD, 14));
            btnContinuar.setBackground(new Color(30, 30, 30));
            btnContinuar.setForeground(Color.WHITE);
            btnContinuar.addActionListener(e -> navegarA("PNL_SERVICIOS"));

            JPanel pnlSur = new JPanel();
            pnlSur.setOpaque(false);
            pnlSur.add(btnContinuar);

            add(lblTitulo, BorderLayout.NORTH);
            add(new JScrollPane(txtDetalles), BorderLayout.CENTER);
            add(pnlSur, BorderLayout.SOUTH);
        }
    }

    /**
     * Panel 2: Servicios
     */
    private class PNL_Servicios extends JPanel {
        private JLabel lblEncabezado;
        private JPanel pnlOpcionesServicios;
        private JButton btnVolver, btnGuardar, btnContinuar;

        public PNL_Servicios() {
            setLayout(new BorderLayout(15, 15));
            setBackground(new Color(220, 220, 220));

            lblEncabezado = new JLabel("Selección de Servicios", JLabel.LEFT);
            lblEncabezado.setFont(new Font("Arial", Font.BOLD, 16));

            pnlOpcionesServicios = new JPanel(new GridLayout(0, 2, 10, 10));
            pnlOpcionesServicios.setOpaque(false);

            btnVolver = new JButton("Volver");
            btnGuardar = new JButton("Guardar");
            btnContinuar = new JButton("Continuar");

            btnVolver.addActionListener(e -> navegarA("PNL_FOLIO"));
            btnContinuar.addActionListener(e -> navegarA("PNL_EQUIPO"));

            JPanel pnlSur = new JPanel();
            pnlSur.setOpaque(false);
            pnlSur.add(btnVolver);
            pnlSur.add(btnGuardar);
            pnlSur.add(btnContinuar);

            add(lblEncabezado, BorderLayout.NORTH);
            add(pnlOpcionesServicios, BorderLayout.CENTER);
            add(pnlSur, BorderLayout.SOUTH);
        }
    }

    /**
     * Panel 3: Selección de Equipos
     */
    private class PNL_Equipo extends JPanel {
        private JLabel lblEncabezado;
        private JTable tblEquipos;
        private JButton btnConsultarInventario, btnConsultarProveedor, btnVolver, btnContinuar;

        public PNL_Equipo() {
            setLayout(new BorderLayout(15, 15));
            setBackground(new Color(220, 220, 220));

            lblEncabezado = new JLabel("Selección De Equipos", JLabel.LEFT);
            lblEncabezado.setFont(new Font("Arial", Font.BOLD, 16));

            tblEquipos = new JTable();

            btnConsultarInventario = new JButton("Consultar Inventario");
            btnConsultarProveedor = new JButton("Consultar Proveedor");

            btnConsultarInventario.addActionListener(e -> navegarA("PNL_PROVEEDOR"));
            btnConsultarProveedor.addActionListener(e -> navegarA("PNL_PROVEEDOR"));

            JPanel pnlCentro = new JPanel(new BorderLayout(10, 10));
            pnlCentro.setOpaque(false);
            pnlCentro.add(new JScrollPane(tblEquipos), BorderLayout.CENTER);

            JPanel pnlAccionesTabla = new JPanel();
            pnlAccionesTabla.setOpaque(false);
            pnlAccionesTabla.add(btnConsultarInventario);
            pnlAccionesTabla.add(btnConsultarProveedor);
            pnlCentro.add(pnlAccionesTabla, BorderLayout.SOUTH);

            btnVolver = new JButton("Volver");
            btnContinuar = new JButton("Continuar");

            btnVolver.addActionListener(e -> navegarA("PNL_SERVICIOS"));
            btnContinuar.addActionListener(e -> navegarA("PNL_PERSONAL"));

            JPanel pnlSur = new JPanel();
            pnlSur.setOpaque(false);
            pnlSur.add(btnVolver);
            pnlSur.add(btnContinuar);

            add(lblEncabezado, BorderLayout.NORTH);
            add(pnlCentro, BorderLayout.CENTER);
            add(pnlSur, BorderLayout.SOUTH);
        }
    }

    /**
     * Panel 4: Consulta de Proveedor / Inventario
     */
    private class PNL_Proveedor extends JPanel {
        private JTextField txtBuscar;
        private JButton btnBuscar, btnCerrar, btnUsarCantidad;
        private JTable tblConsulta;

        public PNL_Proveedor() {
            setLayout(new BorderLayout(15, 15));
            setBackground(new Color(220, 220, 220));

            JLabel lblTitulo = new JLabel("Consulta de Inventario de Proveedor Externo / Propio", JLabel.LEFT);
            lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));

            JPanel pnlBusqueda = new JPanel();
            pnlBusqueda.setOpaque(false);
            txtBuscar = new JTextField(20);
            btnBuscar = new JButton("Buscar");
            pnlBusqueda.add(new JLabel("Buscar equipo: "));
            pnlBusqueda.add(txtBuscar);
            pnlBusqueda.add(btnBuscar);

            tblConsulta = new JTable();

            btnCerrar = new JButton("Cerrar");
            btnUsarCantidad = new JButton("Usar cantidad");

            btnCerrar.addActionListener(e -> navegarA("PNL_EQUIPO"));
            btnUsarCantidad.addActionListener(e -> navegarA("PNL_EQUIPO"));

            JPanel pnlSur = new JPanel();
            pnlSur.setOpaque(false);
            pnlSur.add(btnCerrar);
            pnlSur.add(btnUsarCantidad);

            JPanel pnlCentro = new JPanel(new BorderLayout(10, 10));
            pnlCentro.setOpaque(false);
            pnlCentro.add(pnlBusqueda, BorderLayout.NORTH);
            pnlCentro.add(new JScrollPane(tblConsulta), BorderLayout.CENTER);

            add(lblTitulo, BorderLayout.NORTH);
            add(pnlCentro, BorderLayout.CENTER);
            add(pnlSur, BorderLayout.SOUTH);
        }
    }

    /**
     * Panel 5: Personal Requerido
     */
    private class PNL_Personal extends JPanel {
        private JLabel lblEncabezado;
        private JTable tblPersonal;
        private JButton btnVolver, btnContinuar;

        public PNL_Personal() {
            setLayout(new BorderLayout(15, 15));
            setBackground(new Color(220, 220, 220));

            lblEncabezado = new JLabel("Personal Requerido", JLabel.LEFT);
            lblEncabezado.setFont(new Font("Arial", Font.BOLD, 16));

            tblPersonal = new JTable();

            btnVolver = new JButton("Volver");
            btnContinuar = new JButton("Continuar");

            btnVolver.addActionListener(e -> navegarA("PNL_EQUIPO"));
            btnContinuar.addActionListener(e -> navegarA("PNL_RESUMEN"));

            JPanel pnlSur = new JPanel();
            pnlSur.setOpaque(false);
            pnlSur.add(btnVolver);
            pnlSur.add(btnContinuar);

            add(lblEncabezado, BorderLayout.NORTH);
            add(new JScrollPane(tblPersonal), BorderLayout.CENTER);
            add(pnlSur, BorderLayout.SOUTH);
        }
    }

    /**
     * Panel 6: Resumen de Propuesta
     */
    private class PNL_Resumen extends JPanel {
        private JLabel lblEncabezado;
        private JTextArea txtResumenPropuesta, txtComentarios;
        private JButton btnVolver, btnEnviarCotizacion;

        public PNL_Resumen() {
            setLayout(new BorderLayout(15, 15));
            setBackground(new Color(220, 220, 220));

            lblEncabezado = new JLabel("Resumen de la Propuesta", JLabel.LEFT);
            lblEncabezado.setFont(new Font("Arial", Font.BOLD, 16));

            txtResumenPropuesta = new JTextArea();
            txtResumenPropuesta.setEditable(false);

            txtComentarios = new JTextArea(4, 20);
            txtComentarios.setBorder(BorderFactory.createTitledBorder("Comentarios:"));

            JPanel pnlCentro = new JPanel(new BorderLayout(10, 10));
            pnlCentro.setOpaque(false);
            pnlCentro.add(new JScrollPane(txtResumenPropuesta), BorderLayout.CENTER);
            pnlCentro.add(txtComentarios, BorderLayout.SOUTH);

            btnVolver = new JButton("Volver");
            btnEnviarCotizacion = new JButton("Enviar a cotización");

            btnVolver.addActionListener(e -> navegarA("PNL_PERSONAL"));

            JPanel pnlSur = new JPanel();
            pnlSur.setOpaque(false);
            pnlSur.add(btnVolver);
            pnlSur.add(btnEnviarCotizacion);

            add(lblEncabezado, BorderLayout.NORTH);
            add(pnlCentro, BorderLayout.CENTER);
            add(pnlSur, BorderLayout.SOUTH);
        }
    }
}